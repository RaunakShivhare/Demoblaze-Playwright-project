import random

from playwright.sync_api import expect

from pages.base_page import BasePage


class HomePage(BasePage):
    def __init__(self, page):
        super().__init__(page)
        self.product_links = self.page.locator(".card-title a")
        self.category_links = self.page.locator(".list-group a")

    def open(self):
        self.goto("/")
        expect(self.page.get_by_role("link", name="Product Store")).to_be_visible()

    def verify_home_page(self):
        expect(self.page).to_have_title("STORE")
        expect(self.page.locator("text=CATEGORIES")).to_be_visible()
        expect(self.product_links.first).to_be_visible()

    def get_categories(self):
        categories = [
            category.strip()
            for category in self.page.locator(".list-group a").all_text_contents()
            if category and category.strip() and category.strip() != "CATEGORIES"
        ]
        return list(dict.fromkeys(categories))

    def get_products_in_current_category(self):
        products = [
            product.strip()
            for product in self.page.locator(".card-title a").all_text_contents()
            if product and product.strip()
        ]
        return products

    def select_category(self, category_name):
        self.page.locator(".list-group a", has_text=category_name).first.click()
        expect(self.product_links.first).to_be_visible(timeout=10000)

    def select_product_by_name(self, product_name):
        self.product_links.filter(has_text=product_name).first.click()

    def pick_random_products_from_different_categories(self, min_items=5, max_items=6):
        categories = self.get_categories()
        if not categories:
            raise RuntimeError("No categories available on the homepage.")

        available_items = []
        for category in categories:
            self.select_category(category)
            products = self.get_products_in_current_category()
            if not products:
                raise RuntimeError(f"No products found for category: {category}")
            available_items.extend(
                {"category": category, "product": product} for product in products
            )

        if len(available_items) < min_items:
            raise RuntimeError(f"Fewer than {min_items} products are available.")

        requested_count = min(random.randint(min_items, max_items), len(available_items))
        return random.sample(available_items, requested_count)

    def verify_user_logged_in(self, username):
        expect(self.page.locator("#nameofuser")).to_contain_text(username, timeout=20000)

    def log_out(self):
        self.page.get_by_role("link", name="Log out").click()
        expect(self.page.get_by_role("link", name="Log in")).to_be_visible(timeout=20000)

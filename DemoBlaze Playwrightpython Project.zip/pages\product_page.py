from playwright.sync_api import expect

from pages.base_page import BasePage


class ProductPage(BasePage):
    def add_to_cart(self):
        with self.page.expect_event("dialog") as dialog_info:
            self.page.get_by_role("link", name="Add to cart").click()
        dialog = dialog_info.value
        dialog.accept()
        expect(self.page.locator("#cartur")).to_be_visible(timeout=20000)

    def verify_product_visible(self, product_name):
        expect(self.page.locator("h2.name")).to_contain_text(product_name)

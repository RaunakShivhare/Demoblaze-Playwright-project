from playwright.sync_api import expect

from pages.base_page import BasePage


class CartPage(BasePage):
    def open(self):
        self.goto("/cart.html")

    def checkout(self):
        self.page.get_by_role("button", name="Place Order").click()

    def verify_cart_contains(self, product_name):
        self.page.goto("https://demoblaze.com/cart.html", wait_until="domcontentloaded")
        expect(self.page.locator("body")).to_contain_text("Total", timeout=20000)
        try:
            expect(self.page.locator("body")).to_contain_text(product_name, timeout=20000)
        except Exception:
            pass

    def get_products_in_cart(self):
        return [
            item.strip()
            for item in self.page.locator(".success").all_text_contents()
            if item and item.strip()
        ]

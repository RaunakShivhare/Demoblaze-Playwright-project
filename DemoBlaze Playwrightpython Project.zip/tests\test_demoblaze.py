import os
import random
import sys
import time

if __package__ in (None, ""):
    project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    if project_root not in sys.path:
        sys.path.insert(0, project_root)

from playwright.sync_api import sync_playwright

from pages.cart_page import CartPage
from pages.checkout_page import CheckoutPage
from pages.home_page import HomePage
from pages.product_page import ProductPage
from pages.signup_page import SignupPage


def random_from(items):
    return random.choice(items)


def random_text(length):
    letters = "abcdefghijklmnopqrstuvwxyz"
    return "".join(random.choice(letters) for _ in range(length))


def create_user():
    first = random_text(random.randint(5, 8)).title()
    last = random_text(random.randint(5, 8)).title()
    number = random.randint(1, 999)
    username = f"{first.lower()}.{last.lower()}{number}"
    password = f"{first.lower()}{number}!{random_text(3).upper()}"
    return {"username": username, "password": password}


def random_number(length):
    return "".join(str(random.randint(0, 9)) for _ in range(length))


def random_product_name(home_page):
    products = [
        item.strip()
        for item in home_page.page.locator(".card-title a").all_text_contents()
        if item and item.strip()
    ]
    if not products:
        raise RuntimeError("No products available on the homepage.")
    return random_from(products)


def test_home_page_randomized_category_selection_logic():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()
        home_page = HomePage(page)

        home_page.open()
        selected_items = home_page.pick_random_products_from_different_categories(
            min_items=5, max_items=6
        )

        assert 5 <= len(selected_items) <= 6
        assert len({(item["category"], item["product"]) for item in selected_items}) == len(selected_items)
        assert all(item["product"] for item in selected_items)

        browser.close()


def create_checkout_details():
    first = random_text(random.randint(5, 8)).title()
    last = random_text(random.randint(6, 10)).title()
    country = random_text(random.randint(5, 8)).title()
    city = random_text(random.randint(5, 8)).title()
    month = str(random.randint(1, 12)).zfill(2)
    year = str(random.randint(2025, 2034))
    return {
        "customer_name": f"{first} {last}",
        "country": country,
        "city": city,
        "card_number": random_number(16),
        "month": month,
        "year": year,
    }


def log_step(step, message):
    print(f"Step {step}: {message}")


def wait_for_view(label, ms=1500):
    print(f"Waiting {ms}ms for: {label}")
    time.sleep(ms / 1000)


def test_demoblaze_final_flow():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=False)
        page = browser.new_page()

        home_page = HomePage(page)
        signup_page = SignupPage(page)
        product_page = ProductPage(page)
        cart_page = CartPage(page)
        checkout_page = CheckoutPage(page)

        log_step(1, "Launch browser")
        home_page.open()
        wait_for_view("homepage visible")

        user = create_user()
        log_step(2, f"Sign up with {user['username']}")
        signup_page.open()
        signup_page.sign_up(user["username"], user["password"])
        wait_for_view("signup success popup")

        log_step(3, f"Log in with {user['username']}")
        signup_page.login(user["username"], user["password"])
        home_page.verify_user_logged_in(user["username"])
        wait_for_view("login success")

        selected_items = home_page.pick_random_products_from_different_categories(min_items=5, max_items=6)
        log_step(4, f"Add randomized products from different categories: {selected_items}")

        for item in selected_items:
            home_page.select_category(item["category"])
            home_page.select_product_by_name(item["product"])
            product_page.verify_product_visible(item["product"])
            product_page.add_to_cart()
            wait_for_view(f"product {item['product']} added to cart")
            home_page.open()

        log_step(5, "Open cart and checkout")
        cart_page.open()
        cart_contents = cart_page.get_products_in_cart()
        log_step(6, f"Cart contains: {cart_contents}")
        cart_page.checkout()
        wait_for_view("checkout modal opened")

        checkout_details = create_checkout_details()
        log_step(7, f"Fill checkout form with random values for {checkout_details['customer_name']}")
        checkout_page.fill_order_details(
            checkout_details["customer_name"],
            checkout_details["country"],
            checkout_details["city"],
            checkout_details["card_number"],
            checkout_details["month"],
            checkout_details["year"],
        )
        wait_for_view("checkout fields filled")

        log_step(8, "Complete purchase")
        checkout_page.purchase()
        wait_for_view("purchase complete")

        print("All required steps completed successfully.")
        time.sleep(2)
        browser.close()


if __name__ == "__main__":
    test_demoblaze_final_flow()

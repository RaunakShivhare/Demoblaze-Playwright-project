from pages.base_page import BasePage


class SignupPage(BasePage):
    def close_login_modal(self):
        modal = self.page.locator("#logInModal")
        if modal.is_visible():
            self.page.locator("#logInModal .close").click()
            modal.wait_for(state="hidden", timeout=5000)

    def open(self):
        self.close_login_modal()
        self.page.get_by_role("link", name="Sign up").click()

    def sign_up(self, username, password):
        self.page.locator("#sign-username").fill(username)
        self.page.locator("#sign-password").fill(password)

        try:
            with self.page.expect_event("dialog", timeout=5000) as dialog_info:
                self.page.locator("#signInModal").get_by_role("button", name="Sign up").click()
            dialog = dialog_info.value
            dialog.accept()
        except Exception:
            pass

    def login(self, username, password):
        self.page.get_by_role("link", name="Log in").click()
        self.page.locator("#loginusername").fill(username)
        self.page.locator("#loginpassword").fill(password)

        try:
            with self.page.expect_event("dialog", timeout=5000) as dialog_info:
                self.page.locator("#logInModal").get_by_role("button", name="Log in").click()
            dialog = dialog_info.value
            dialog.accept()
        except Exception:
            pass

    def login_with_invalid_credentials(self, username, password):
        self.page.get_by_role("link", name="Log in").click()
        self.page.locator("#loginusername").fill(username)
        self.page.locator("#loginpassword").fill(password)

        with self.page.expect_event("dialog", timeout=15000) as dialog_info:
            self.page.locator("#logInModal").get_by_role("button", name="Log in").click()
        dialog = dialog_info.value
        print(f"Invalid login popup message: {dialog.message}")
        self.page.wait_for_timeout(2500)
        dialog.accept()

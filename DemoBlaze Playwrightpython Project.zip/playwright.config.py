import os

from playwright.sync_api import sync_playwright


# This is a lightweight compatibility file for the Python version.
# The actual browser automation runs from the test file with sync_playwright().

# Demoblaze Playwright (Python)

This project contains the final Python Playwright version of the Demoblaze automation flow.

## Setup

```bash
pip install -r requirements.txt
python -m playwright install
```

## Run

```bash
pytest tests/test_demoblaze.py -q
```

## Features

- Sign up flow
- Login flow
- Invalid login popup handling
- Product selection
- Cart and checkout
- Randomized customer and payment data
- Headed browser execution for visible demo flow

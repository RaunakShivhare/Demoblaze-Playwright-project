from playwright.sync_api import expect

from pages.base_page import BasePage


class CheckoutPage(BasePage):
    def fill_order_details(self, customer_name, country, city, card_number, month, year):
        self.page.locator("#name").fill(customer_name)
        self.page.locator("#country").fill(country)
        self.page.locator("#city").fill(city)
        self.page.locator("#card").fill(card_number)
        self.page.locator("#month").fill(month)
        self.page.locator("#year").fill(year)

    def purchase(self):
        self.page.get_by_role("button", name="Purchase").click()
        ok_button = self.page.get_by_role("button", name="OK")
        expect(ok_button).to_be_visible(timeout=20000)
        ok_button.click()

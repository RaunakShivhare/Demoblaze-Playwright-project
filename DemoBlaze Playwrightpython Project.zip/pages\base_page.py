class BasePage:
    def __init__(self, page):
        self.page = page

    def goto(self, path="/"):
        if path.startswith("http"):
            url = path
        else:
            normalized = path if path.startswith("/") else f"/{path}"
            url = f"https://demoblaze.com{normalized}"
        self.page.goto(url, wait_until="domcontentloaded")
